# Roteiro do Vídeo de Demonstração (até 3 minutos)

> Objetivo: mostrar o chatbot funcionando com **pelo menos 3 interações relevantes**
> ao contexto do EV Challenge 2026. Grave a tela (com áudio de narração) rodando o
> `streamlit run src/app.py`. Suba no YouTube como **não listado** e cole o link no
> README e no arquivo de entrega.

## Antes de gravar (checklist)
- [ ] `.env` configurado com a `GROQ_API_KEY` (a chave NÃO deve aparecer na tela).
- [ ] App aberto: `streamlit run src/app.py`.
- [ ] Conversa limpa (botão "Limpar conversa" na barra lateral).
- [ ] Microfone testado.

---

## Estrutura sugerida (≈ 3 min)

### 0:00 – 0:25 — Abertura
- "Olá, somos o grupo do projeto **GoodWe ChargeOps Assistant**, do EV Challenge 2026,
  parceria FIAP e GoodWe."
- "É um chatbot operacional para **síndicos e administradores** gerenciarem o uso
  compartilhado de **carregadores de veículos elétricos em condomínios**."
- Mostre rapidamente a tela inicial do app.

### 0:25 – 0:50 — Contexto técnico (mostrando o código por alguns segundos)
- "O contexto é injetado via **system prompt**; mantemos **histórico de mensagens**
  para diálogos contínuos; e usamos **few-shot prompting** e **function calling** como
  diferenciais."
- Mostre rapidamente `system_prompt.txt` e `src/chatbot.py`.

### 0:50 – 1:30 — Interação 1 (organização / regras)
- Pergunte: **"Como organizo o uso do carregador entre os 15 moradores do meu condomínio?"**
- Destaque a resposta operacional (agenda, limite de tempo, registro de ciclos).

### 1:30 – 2:05 — Interação 2 (memória de contexto)
- Pergunte, sem repetir os números: **"E se dois deles quiserem o mesmo horário?"**
- Aponte: "Repare que ele **lembrou** do contexto anterior (os 15 moradores)."

### 2:05 – 2:40 — Interação 3 (function calling)
- Pergunte: **"Registre o ciclo do morador João, do dia 2026-06-10, com 12 kWh."**
- Mostre a confirmação e, se quiser, abra o `registro_ciclos.csv` provando o registro.

### 2:40 – 3:00 — Fechamento (opcional: pergunta fora de escopo)
- Pergunte algo fora do tema (ex.: "Qual a previsão do tempo amanhã?") e mostre que o
  chatbot **educadamente recusa** e reforça seu escopo.
- Encerre: "Esse é o GoodWe ChargeOps Assistant. Obrigado!"

---

## Dicas
- Fale o que está fazendo enquanto digita.
- Mantenha cada resposta visível por tempo suficiente para leitura.
- Não mostre a chave de API em nenhum momento (terminal, .env aberto, etc.).
