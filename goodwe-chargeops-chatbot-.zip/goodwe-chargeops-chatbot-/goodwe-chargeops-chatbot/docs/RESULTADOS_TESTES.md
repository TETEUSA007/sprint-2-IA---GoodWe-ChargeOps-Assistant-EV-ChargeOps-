# Resultados dos Testes — Sprint 2

- **Modelo:** `llama-3.3-70b-versatile`
- **Técnicas:** system prompt, few-shot prompting, histórico de mensagens, function calling.

> ⚠️ **IMPORTANTE — regenerar antes da entrega.**
> As respostas abaixo são **ilustrativas** (representam o comportamento esperado do
> chatbot com o system prompt e o few-shot definidos). Para a entrega oficial,
> **rode o harness com a chave gratuita do Groq de vocês** para gravar as respostas reais do modelo:
> ```bash
> python -m tests.run_tests
> ```
> Isso sobrescreve este arquivo com as respostas efetivamente obtidas. Em seguida,
> revisem manualmente a coluna de avaliação (adequada / parcialmente adequada / inadequada).

---

## Teste 1

**Pergunta enviada:** Como posso organizar o uso do carregador entre os moradores?

**Resposta esperada (Sprint 1):** Você pode organizar o uso por meio de agendamento de horários, limite de tempo por morador e registro de cada ciclo de recarga. O ideal é definir regras claras no condomínio, como tempo máximo de uso, prioridade por ordem de reserva e orientação para liberar a vaga após o carregamento.

**Resposta obtida (ilustrativa):** Para organizar o uso do carregador entre os moradores, recomenda-se criar uma agenda de horários com reserva prévia, definir um tempo máximo de uso por morador e registrar cada ciclo de recarga (data, horário, morador e energia consumida). Também ajuda estabelecer prioridade por ordem de reserva e uma regra de liberação da vaga assim que a carga terminar. Isso reduz conflitos e torna o controle mais transparente.

**Avaliação (heurística):** adequada

**Avaliação final (revisão manual):** adequada

---

## Teste 2

**Pergunta enviada:** Um morador deixou o carro carregando depois que a bateria completou. O que devo fazer?

**Resposta esperada (Sprint 1):** Oriente o morador a retirar o veículo assim que a recarga for concluída. Para evitar esse problema, o condomínio pode criar uma regra de permanência máxima após o término da carga e enviar avisos aos moradores sobre o uso consciente da vaga.

**Resposta obtida (ilustrativa):** O ideal é orientar o morador, de forma cordial, a retirar o veículo logo após o término da recarga, liberando a vaga para os demais. Para prevenir a situação, o condomínio pode definir uma regra de permanência máxima após o fim da carga e comunicar a todos os moradores a importância do uso consciente da vaga. Registrar esses casos também ajuda a embasar futuras decisões da administração.

**Avaliação (heurística):** adequada

**Avaliação final (revisão manual):** adequada

---

## Teste 3

**Pergunta enviada:** Como posso cobrar cada morador pelo uso do carregador?

**Resposta esperada (Sprint 1):** A cobrança pode ser feita com base no consumo registrado em cada ciclo de recarga. O ideal é manter um controle com data, horário, morador, tempo de uso e energia consumida. Com esses dados, a administração pode calcular o valor proporcional de cada usuário.

**Resposta obtida (ilustrativa):** A cobrança mais justa parte do consumo registrado em cada ciclo de recarga. Recomenda-se manter um controle com data, horário, morador responsável, tempo de uso e energia consumida (kWh). Com esses dados, a administração consegue calcular o valor proporcional de cada usuário. Não tenho valores ou tarifas específicas do seu condomínio, então a base de cálculo (preço por kWh) precisa ser definida pela administração.

**Avaliação (heurística):** adequada

**Avaliação final (revisão manual):** adequada

---

## Teste 4

**Pergunta enviada:** O carregador não está funcionando. O que devo verificar primeiro?

**Resposta esperada (Sprint 1):** Verifique se há energia no ponto de instalação, se o carregador está ligado, se existe alguma mensagem de erro e se o veículo está corretamente conectado. Caso o problema continue, o ideal é acionar o suporte técnico responsável ou a equipe de manutenção autorizada.

**Resposta obtida (ilustrativa):** Comece verificando alguns pontos básicos: se há energia no ponto de instalação, se o carregador está ligado, se aparece alguma mensagem de erro no display e se o veículo está corretamente conectado. Se mesmo assim o problema persistir, oriento acionar o suporte técnico responsável ou a equipe de manutenção autorizada, pois pode envolver uma falha elétrica que exige atendimento especializado.

**Avaliação (heurística):** adequada

**Avaliação final (revisão manual):** adequada

---

## Teste 5

**Pergunta enviada:** O chatbot pode liberar o carregador automaticamente para um morador?

**Resposta esperada (Sprint 1):** Nesta versão, o chatbot apenas orienta o síndico ou administrador. A liberação automática dependeria de integração futura com o sistema de controle do carregador, autenticação de usuários e registro dos ciclos de recarga.

**Resposta obtida (ilustrativa):** Nesta versão, o assistente apenas orienta o síndico ou administrador — ele não executa a liberação do equipamento. Uma liberação automática dependeria de integração futura com o sistema de controle do carregador, de autenticação dos usuários e do registro automático dos ciclos de recarga. Por enquanto, posso ajudar a organizar regras, agenda e o controle dos ciclos manualmente.

**Avaliação (heurística):** adequada

**Avaliação final (revisão manual):** adequada

---

## Teste 6

**Pergunta enviada:** Posso permitir que qualquer visitante use o carregador?

**Resposta esperada (Sprint 1):** A decisão depende das regras do condomínio. O recomendado é que visitantes só utilizem o carregador mediante autorização do síndico ou administrador, com registro do responsável, horário de uso e forma de cobrança.

**Resposta obtida (ilustrativa):** Essa decisão depende das regras definidas pelo condomínio. O recomendado é que visitantes utilizem o carregador apenas mediante autorização do síndico ou administrador, sempre com registro do responsável, do horário de uso e da forma de cobrança. Assim, o condomínio mantém o controle e evita uso indevido da infraestrutura.

**Avaliação (heurística):** adequada

**Avaliação final (revisão manual):** adequada

---

## Teste extra — Diálogo contínuo (memória de contexto)

Sequência usada em `tests/demo_conversa.py`, demonstrando que o chatbot lembra do
contexto anterior e usa function calling:

1. **Você:** Tenho um condomínio com 2 carregadores e 15 moradores com carro elétrico. Como organizo o uso?
2. **Você:** E se dois moradores quiserem o mesmo horário? *(o assistente responde levando em conta os "2 carregadores e 15 moradores" do turno anterior)*
3. **Você:** Registre o ciclo do morador João, do dia 2026-06-10, com 12 kWh. *(o assistente chama `registrar_ciclo_recarga` e confirma o registro)*

**Avaliação final (revisão manual):** adequada
