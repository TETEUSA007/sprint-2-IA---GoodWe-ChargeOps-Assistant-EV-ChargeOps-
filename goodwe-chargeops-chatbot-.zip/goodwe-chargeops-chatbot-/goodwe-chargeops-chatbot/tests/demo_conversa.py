"""
demo_conversa.py
Demonstra a MEMÓRIA DE CONTEXTO: uma conversa de vários turnos em que o
chatbot precisa lembrar do que foi dito antes para responder coerentemente.

Boa sequência para usar no vídeo de demonstração.

Uso:
    python -m tests.demo_conversa
"""

from src.chatbot import ChargeOpsChatbot


SEQUENCIA = [
    "Tenho um condomínio com 2 carregadores e 15 moradores com carro elétrico. "
    "Como organizo o uso?",
    # Depende da resposta anterior — testa a memória:
    "E se dois moradores quiserem o mesmo horário?",
    # Continua o contexto e dispara o function calling:
    "Registre o ciclo do morador João, do dia 2026-06-10, com 12 kWh.",
]


def main() -> None:
    bot = ChargeOpsChatbot()
    for i, pergunta in enumerate(SEQUENCIA, start=1):
        print(f"\n[Turno {i}] Você: {pergunta}")
        resposta = bot.enviar(pergunta)
        print(f"[Turno {i}] Assistente: {resposta}")


if __name__ == "__main__":
    main()
