"""
run_tests.py
Executa os casos de teste da Sprint 1 contra o chatbot e gera um relatório
em Markdown (docs/RESULTADOS_TESTES.md) com:
- pergunta enviada
- resposta obtida
- avaliação qualitativa (heurística automática + espaço para revisão manual)

Cada caso é executado em uma instância NOVA do chatbot, para que um teste
não interfira no outro. Para avaliar o diálogo contínuo (memória de
contexto), veja o teste de conversa ao final.

Uso:
    python -m tests.run_tests
"""

import json
from datetime import datetime
from pathlib import Path

from src.chatbot import ChargeOpsChatbot
from src.config import GROQ_MODEL

BASE_DIR = Path(__file__).resolve().parent.parent
CASOS_PATH = BASE_DIR / "tests" / "test_cases.json"
SAIDA_PATH = BASE_DIR / "docs" / "RESULTADOS_TESTES.md"


def carregar_casos() -> list[dict]:
    dados = json.loads(CASOS_PATH.read_text(encoding="utf-8"))
    return dados["casos"]


def avaliar_heuristica(resposta: str, esperada: str) -> str:
    """
    Avaliação automática simples por sobreposição de palavras-chave.
    Serve como ponto de partida; a avaliação final deve ser revisada
    manualmente (adequada / parcialmente adequada / inadequada).
    """
    if not resposta:
        return "inadequada"

    stop = {
        "de", "o", "a", "os", "as", "e", "que", "do", "da", "no", "na", "um",
        "uma", "para", "com", "por", "em", "se", "ou", "ao", "à", "como", "the",
    }
    palavras_esperadas = {
        p for p in esperada.lower().replace(",", " ").replace(".", " ").split()
        if len(p) > 3 and p not in stop
    }
    palavras_resposta = set(resposta.lower().split())
    if not palavras_esperadas:
        return "parcialmente adequada"

    cobertura = len(palavras_esperadas & palavras_resposta) / len(palavras_esperadas)
    if cobertura >= 0.4:
        return "adequada"
    if cobertura >= 0.2:
        return "parcialmente adequada"
    return "inadequada"


def main() -> None:
    casos = carregar_casos()
    linhas: list[str] = []

    linhas.append("# Resultados dos Testes — Sprint 2")
    linhas.append("")
    linhas.append(f"- **Gerado em:** {datetime.now():%d/%m/%Y %H:%M}")
    linhas.append(f"- **Modelo:** `{GROQ_MODEL}`")
    linhas.append("- **Técnicas:** system prompt, few-shot prompting, histórico de mensagens, function calling.")
    linhas.append("")
    linhas.append(
        "> A coluna *Avaliação (heurística)* é gerada automaticamente por "
        "sobreposição de palavras-chave e deve ser **revisada manualmente** "
        "pelo grupo, classificando como adequada / parcialmente adequada / inadequada."
    )
    linhas.append("")

    for caso in casos:
        bot = ChargeOpsChatbot()  # instância nova por caso
        resposta = bot.enviar(caso["pergunta"])
        avaliacao = avaliar_heuristica(resposta, caso["resposta_esperada"])

        linhas.append(f"## Teste {caso['id']}")
        linhas.append("")
        linhas.append(f"**Pergunta enviada:** {caso['pergunta']}")
        linhas.append("")
        linhas.append(f"**Resposta esperada (Sprint 1):** {caso['resposta_esperada']}")
        linhas.append("")
        linhas.append(f"**Resposta obtida:** {resposta}")
        linhas.append("")
        linhas.append(f"**Avaliação (heurística):** {avaliacao}")
        linhas.append("")
        linhas.append("**Avaliação final (revisão manual):** _________________")
        linhas.append("")
        linhas.append("---")
        linhas.append("")

    SAIDA_PATH.write_text("\n".join(linhas), encoding="utf-8")
    print(f"Relatório gerado em: {SAIDA_PATH}")


if __name__ == "__main__":
    main()
