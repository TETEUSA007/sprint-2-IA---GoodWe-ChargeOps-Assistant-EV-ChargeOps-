"""
app.py
Interface web (Streamlit) do GoodWe ChargeOps Assistant.

Uso:
    streamlit run src/app.py
"""

# Garante que a pasta raiz do projeto esteja no caminho de importação,
# para que "from src.chatbot import ..." funcione mesmo rodando via
# "streamlit run src/app.py" (o Streamlit não adiciona a raiz por padrão).
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

from src.chatbot import ChargeOpsChatbot

st.set_page_config(page_title="GoodWe ChargeOps Assistant", page_icon="🔌")

st.title("🔌 GoodWe ChargeOps Assistant")
st.caption("EV Challenge 2026 — FIAP × GoodWe • Gestão de carregadores EV em condomínios")

# Inicializa o chatbot e o histórico visível uma única vez por sessão.
if "bot" not in st.session_state:
    try:
        st.session_state.bot = ChargeOpsChatbot()
        st.session_state.mensagens = []
    except Exception as erro:  # noqa: BLE001
        st.error(f"Erro ao iniciar o chatbot: {erro}")
        st.stop()

with st.sidebar:
    st.subheader("Sobre")
    st.write(
        "Assistente operacional para síndicos e administradores de condomínios "
        "com carregadores de veículos elétricos."
    )
    if st.button("Limpar conversa"):
        st.session_state.bot.resetar()
        st.session_state.mensagens = []
        st.rerun()

# Renderiza o histórico de mensagens.
for msg in st.session_state.mensagens:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Caixa de entrada.
pergunta = st.chat_input("Pergunte sobre o uso dos carregadores...")
if pergunta:
    st.session_state.mensagens.append({"role": "user", "content": pergunta})
    with st.chat_message("user"):
        st.markdown(pergunta)

    with st.chat_message("assistant"):
        with st.spinner("Pensando..."):
            try:
                resposta = st.session_state.bot.enviar(pergunta)
            except Exception as erro:  # noqa: BLE001
                resposta = f"Ocorreu um erro: {erro}"
            st.markdown(resposta)

    st.session_state.mensagens.append({"role": "assistant", "content": resposta})
