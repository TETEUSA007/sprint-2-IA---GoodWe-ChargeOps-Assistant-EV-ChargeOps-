"""
chatbot.py
Núcleo do GoodWe ChargeOps Assistant (versão Groq + Llama).

Responsabilidades:
- Injetar o contexto via system prompt (Sprint 1).
- Aplicar few-shot prompting (diferencial).
- Manter o histórico de mensagens (memória de contexto / diálogo contínuo).
- Suportar function calling para registrar ciclos de recarga (diferencial).
"""

import json

from groq import Groq

from src.config import (
    GROQ_MODEL,
    TEMPERATURE,
    load_system_prompt,
    get_api_key,
)
from src.few_shot import FEW_SHOT_EXEMPLOS
from src.tools import TOOLS_SPEC, FUNCOES_DISPONIVEIS


class ChargeOpsChatbot:
    """Assistente operacional de carregadores EV para condomínios."""

    def __init__(
        self,
        model: str = GROQ_MODEL,
        temperature: float = TEMPERATURE,
        usar_few_shot: bool = True,
        usar_ferramentas: bool = True,
    ):
        api_key = get_api_key()
        self.client = Groq(api_key=api_key)
        self.model = model
        self.temperature = temperature
        self.usar_few_shot = usar_few_shot
        self.usar_ferramentas = usar_ferramentas
        self.system_prompt = load_system_prompt()

        # Histórico apenas dos turnos usuário/assistente.
        self.historico_msgs: list[dict] = []

    def _montar_mensagens(self) -> list[dict]:
        mensagens = [{"role": "system", "content": self.system_prompt}]
        if self.usar_few_shot:
            for ex in FEW_SHOT_EXEMPLOS:
                mensagens.append({"role": "user", "content": ex["pergunta"]})
                mensagens.append({"role": "assistant", "content": ex["resposta"]})
        mensagens.extend(self.historico_msgs)
        return mensagens

    def enviar(self, mensagem_usuario: str) -> str:
        """Envia uma mensagem do usuário e devolve a resposta do assistente."""
        self.historico_msgs.append({"role": "user", "content": mensagem_usuario})

        tools = TOOLS_SPEC if self.usar_ferramentas else None
        resposta = self.client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            messages=self._montar_mensagens(),
            tools=tools,
        )
        mensagem = resposta.choices[0].message

        if getattr(mensagem, "tool_calls", None):
            return self._tratar_ferramentas(mensagem)

        conteudo = mensagem.content or ""
        self.historico_msgs.append({"role": "assistant", "content": conteudo})
        return conteudo

    def _tratar_ferramentas(self, mensagem) -> str:
        # Registra a mensagem do assistente que solicitou a(s) ferramenta(s).
        self.historico_msgs.append(
            {
                "role": "assistant",
                "content": mensagem.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                    }
                    for tc in mensagem.tool_calls
                ],
            }
        )

        for tool_call in mensagem.tool_calls:
            nome = tool_call.function.name
            try:
                argumentos = json.loads(tool_call.function.arguments or "{}")
            except json.JSONDecodeError:
                argumentos = {}

            funcao = FUNCOES_DISPONIVEIS.get(nome)
            resultado = (
                funcao(**argumentos)
                if funcao
                else {"status": "erro", "mensagem": f"Ferramenta '{nome}' não existe."}
            )

            self.historico_msgs.append(
                {
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": json.dumps(resultado, ensure_ascii=False),
                }
            )

        resposta_final = self.client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            messages=self._montar_mensagens(),
        )
        conteudo = resposta_final.choices[0].message.content or ""
        self.historico_msgs.append({"role": "assistant", "content": conteudo})
        return conteudo

    def resetar(self) -> None:
        """Limpa o histórico de conversa (mantém system prompt e few-shot)."""
        self.historico_msgs = []
