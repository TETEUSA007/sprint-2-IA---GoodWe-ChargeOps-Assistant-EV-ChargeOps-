"""
cli.py
Interface de terminal para conversar com o GoodWe ChargeOps Assistant.

Uso:
    python -m src.cli
"""

from src.chatbot import ChargeOpsChatbot


BANNER = """
============================================================
 GoodWe ChargeOps Assistant — EV Challenge 2026 (FIAP)
 Assistente operacional de carregadores EV em condomínios
------------------------------------------------------------
 Digite sua pergunta. Comandos: 'sair' encerra, 'reset' limpa.
============================================================
"""


def main() -> None:
    print(BANNER)
    bot = ChargeOpsChatbot()

    while True:
        try:
            pergunta = input("\nVocê: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nAtendimento encerrado.")
            break

        if not pergunta:
            continue
        if pergunta.lower() in {"sair", "exit", "quit"}:
            print("Atendimento encerrado.")
            break
        if pergunta.lower() == "reset":
            bot.resetar()
            print("Histórico limpo.")
            continue

        try:
            resposta = bot.enviar(pergunta)
            print(f"\nAssistente: {resposta}")
        except Exception as erro:  # noqa: BLE001
            print(f"\n[Erro] {erro}")


if __name__ == "__main__":
    main()
