"""
few_shot.py
Exemplos de demonstração (few-shot prompting) usados para fixar o TOM e o
FORMATO esperados das respostas.

IMPORTANTE: estes exemplos são DIFERENTES dos 6 casos de teste do
modelo_teste.txt, justamente para que a avaliação na Sprint 2 continue
sendo um teste justo (o modelo não "decora" as respostas dos testes).
"""

FEW_SHOT_EXEMPLOS = [
    {
        "pergunta": "Quantos carregadores devo instalar no condomínio?",
        "resposta": (
            "Essa definição depende da quantidade de veículos elétricos, do perfil "
            "de uso e da capacidade elétrica disponível no condomínio. Como ponto "
            "de partida, recomenda-se levantar quantos moradores possuem ou pretendem "
            "ter veículos elétricos e registrar a demanda. Para dimensionar a carga "
            "elétrica de forma segura, é importante contar com uma avaliação da "
            "equipe técnica responsável pela instalação."
        ),
    },
    {
        "pergunta": "Como aviso os moradores sobre uma nova regra de uso?",
        "resposta": (
            "Você pode comunicar a nova regra por meio dos canais oficiais do "
            "condomínio, como mural, aplicativo de gestão, grupo de moradores ou "
            "comunicado impresso. Recomenda-se descrever de forma clara a regra, a "
            "data de início e o motivo, além de manter o registro do comunicado para "
            "futuras consultas."
        ),
    },
]
