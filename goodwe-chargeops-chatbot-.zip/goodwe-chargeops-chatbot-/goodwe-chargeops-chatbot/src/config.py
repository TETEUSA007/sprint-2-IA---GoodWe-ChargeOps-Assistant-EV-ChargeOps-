"""
config.py
Carrega configurações do chatbot a partir de variáveis de ambiente
e do arquivo de system prompt. Nenhuma chave de API fica no código.
"""

import os
from pathlib import Path

try:
    # Carrega variáveis do arquivo .env, se existir (uso local).
    # Em Google Colab, use os Secrets (userdata) em vez do .env.
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Diretório raiz do projeto (pasta acima de src/)
BASE_DIR = Path(__file__).resolve().parent.parent

# Caminho do arquivo de system prompt (pode ser sobrescrito por env)
SYSTEM_PROMPT_PATH = Path(
    os.environ.get("SYSTEM_PROMPT_PATH", BASE_DIR / "system_prompt.txt")
)

# Modelo e parâmetros (Groq + Llama, gratuito e sem cartão)
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
TEMPERATURE = float(os.environ.get("GROQ_TEMPERATURE", "0.3"))

# Caminho do arquivo onde os ciclos de recarga são registrados (function calling)
REGISTRO_CICLOS_PATH = os.environ.get(
    "REGISTRO_CICLOS_PATH", str(BASE_DIR / "registro_ciclos.csv")
)


def load_system_prompt() -> str:
    """Lê o conteúdo do system prompt a partir do arquivo configurado."""
    if not SYSTEM_PROMPT_PATH.exists():
        raise FileNotFoundError(
            f"Arquivo de system prompt não encontrado em: {SYSTEM_PROMPT_PATH}"
        )
    return SYSTEM_PROMPT_PATH.read_text(encoding="utf-8").strip()


def get_api_key() -> str:
    """
    Recupera a chave da API do Groq da variável de ambiente GROQ_API_KEY.
    Lança erro claro caso não esteja configurada.
    """
    key = os.environ.get("GROQ_API_KEY")
    if not key:
        raise EnvironmentError(
            "A variável de ambiente GROQ_API_KEY não está definida.\n"
            "Pegue uma chave gratuita (sem cartão) em https://console.groq.com/keys "
            "e defina-a no arquivo .env (local) ou nos Secrets do Google Colab."
        )
    return key
