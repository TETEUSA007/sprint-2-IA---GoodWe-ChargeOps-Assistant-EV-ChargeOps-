"""
tools.py
Define a ferramenta de function calling usada pelo chatbot.

Diferencial técnico (Sprint 2): além de responder em linguagem natural,
o assistente pode REGISTRAR um ciclo de recarga quando o síndico informa
os dados de uma carga concluída. O registro é gravado em um CSV local,
simulando o controle operacional que existirá numa integração futura.

O Groq é compatível com o formato de tools da OpenAI.
"""

import os
import csv
from datetime import datetime

from src.config import REGISTRO_CICLOS_PATH


def registrar_ciclo_recarga(
    morador: str,
    data: str,
    energia_kwh: float,
    horario_inicio: str = "",
    horario_fim: str = "",
) -> dict:
    """Registra um ciclo de recarga concluído no controle do condomínio (CSV local)."""
    arquivo_novo = not os.path.exists(REGISTRO_CICLOS_PATH)

    with open(REGISTRO_CICLOS_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if arquivo_novo:
            writer.writerow(
                ["registrado_em", "morador", "data", "horario_inicio", "horario_fim", "energia_kwh"]
            )
        writer.writerow(
            [
                datetime.now().isoformat(timespec="seconds"),
                morador,
                data,
                horario_inicio,
                horario_fim,
                energia_kwh,
            ]
        )

    return {
        "status": "ok",
        "mensagem": (
            f"Ciclo de recarga registrado: morador {morador}, "
            f"data {data}, energia {energia_kwh} kWh."
        ),
    }


# Especificação no formato de tools (compatível OpenAI/Groq).
TOOLS_SPEC = [
    {
        "type": "function",
        "function": {
            "name": "registrar_ciclo_recarga",
            "description": (
                "Registra um ciclo de recarga concluído no controle do condomínio. "
                "Use SOMENTE quando o usuário fornecer dados de uma recarga "
                "(ao menos morador, data e energia em kWh)."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "morador": {"type": "string", "description": "Nome ou identificação do morador."},
                    "data": {"type": "string", "description": "Data da recarga no formato AAAA-MM-DD."},
                    "energia_kwh": {"type": "number", "description": "Energia consumida em kWh."},
                    "horario_inicio": {"type": "string", "description": "Horário de início (HH:MM). Opcional."},
                    "horario_fim": {"type": "string", "description": "Horário de término (HH:MM). Opcional."},
                },
                "required": ["morador", "data", "energia_kwh"],
            },
        },
    }
]

# Mapeia o nome da ferramenta para a função Python correspondente.
FUNCOES_DISPONIVEIS = {"registrar_ciclo_recarga": registrar_ciclo_recarga}
